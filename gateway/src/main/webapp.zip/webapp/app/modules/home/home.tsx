import './home.scss';

import React from 'react';
import { Link } from 'react-router-dom';
import { Translate } from 'react-jhipster';
import { Alert, Col, Row } from 'reactstrap';

import { useAppSelector } from 'app/config/store';

export const Home = () => {
  const account = useAppSelector(state => state.authentication.account);

  return (
    <Row>
      <Col md="12" className="hero-section">
        <div className="hero-text">
          <h1 className="display-4">
            <Translate contentKey="home.title">Welcome to Zenith EBank!</Translate>
          </h1>
          <p className="lead">
            <Translate contentKey="home.subtitle">
              Experience a new era of digital banking. Secure, reliable, and tailored for you.
            </Translate>
          </p>
          {account?.login ? (
            <Alert color="success">
              <Translate contentKey="home.logged.message" interpolate={{ username: account.login }}>
                You are logged in as {account.login}.
              </Translate>
            </Alert>
          ) : (
            <div>
              <Alert color="info">
                <Translate contentKey="global.messages.info.authenticated.prefix">
                  Sign in to access your personalized banking dashboard.
                </Translate>
              </Alert>
              <Link to="/login" className="cta-button">
                <Translate contentKey="global.messages.info.authenticated.link">Sign In</Translate>
              </Link>
              <p className="mt-3">
                <Translate contentKey="global.messages.info.register.noaccount">Don&apos;t have an account yet?</Translate>&nbsp;
                <Link to="/account/register" className="cta-button">
                  <Translate contentKey="global.messages.info.register.link">Register Now</Translate>
                </Link>
              </p>
            </div>
          )}
        </div>
      </Col>
    </Row>
  );
};

export default Home;
