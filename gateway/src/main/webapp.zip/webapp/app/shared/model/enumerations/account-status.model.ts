export enum AccountStatus {
  ACTIVE = 'ACTIVE',

  CLOSED = 'CLOSED',

  SUSPENDED = 'SUSPENDED',
}
