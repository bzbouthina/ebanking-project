export enum AccountType {
  CHECKING = 'CHECKING',

  SAVING = 'SAVING',

  BUSINESS = 'BUSINESS',
}
