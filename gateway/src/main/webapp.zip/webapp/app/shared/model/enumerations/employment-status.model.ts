export enum EmploymentStatus {
  EMPLOYED = 'EMPLOYED',

  STUDENT = 'STUDENT',

  UNEMPLOYED = 'UNEMPLOYED',

  RETIRED = 'RETIRED',
}
