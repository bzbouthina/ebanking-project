export enum Gender {
  MALE = 'MALE',

  FEMALE = 'FEMALE',
}
