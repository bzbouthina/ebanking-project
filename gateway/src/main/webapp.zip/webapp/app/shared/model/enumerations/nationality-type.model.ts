export enum NationalityType {
  LIBYAN = 'LIBYAN',

  FOREIGN_RESIDENT = 'FOREIGN_RESIDENT',
}
